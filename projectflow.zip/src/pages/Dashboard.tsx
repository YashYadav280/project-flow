import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../lib/api';
import { 
  CheckCircle2, 
  Clock, 
  ListTodo, 
  AlertCircle,
  TrendingUp,
  BarChart3
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { motion } from 'motion/react';

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    pending: 0,
    overdue: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const { data: tasks } = await api.get('/tasks');
        const now = new Date();
        const overdue = tasks.filter((t: any) => t.status !== 'Completed' && new Date(t.dueDate) < now).length;
        const completed = tasks.filter((t: any) => t.status === 'Completed').length;
        const pending = tasks.filter((t: any) => t.status !== 'Completed').length;

        setStats({
          total: tasks.length,
          completed,
          pending,
          overdue
        });
      } catch (err) {
        console.error('Failed to fetch dashboard stats', err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const chartData = [
    { name: 'Completed', value: stats.completed },
    { name: 'Pending', value: stats.pending },
    { name: 'Overdue', value: stats.overdue },
  ];

  const COLORS = ['#10b981', '#3b82f6', '#ef4444'];

  if (loading) return <div className="flex items-center justify-center h-full"><BarChart3 className="animate-pulse w-12 h-12 text-blue-400" /></div>;

  return (
    <div className="max-w-7xl mx-auto pb-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Dashboard Overview</h1>
        <p className="text-slate-400 text-sm italic font-medium">Monitoring {stats.total} total tasks across all workspaces</p>
      </div>

      <main className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Productivity Stats */}
        <section className="col-span-1 md:col-span-4 bento-card flex flex-col justify-between">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-6">Productivity</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                <p className="text-blue-600 text-[10px] font-bold uppercase tracking-wider">Total</p>
                <p className="text-2xl font-black text-blue-900">{stats.total}</p>
              </div>
              <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                <p className="text-emerald-600 text-[10px] font-bold uppercase tracking-wider">Done</p>
                <p className="text-2xl font-black text-emerald-900">{stats.completed}</p>
              </div>
              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100">
                <p className="text-amber-600 text-[10px] font-bold uppercase tracking-wider">Pending</p>
                <p className="text-2xl font-black text-amber-900">{stats.pending}</p>
              </div>
              <div className="bg-rose-50 p-4 rounded-2xl border border-rose-100">
                <p className="text-rose-600 text-[10px] font-bold uppercase tracking-wider">Overdue</p>
                <p className="text-2xl font-black text-rose-900">{stats.overdue}</p>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-slate-50 flex items-end gap-2 h-20 justify-center">
            {[40, 60, 90, 70, 50, 80, 45].map((h, i) => (
              <div 
                key={i} 
                className={`w-3 rounded-t-lg transition-all ${i === 2 ? 'bg-blue-400' : 'bg-slate-100'}`} 
                style={{ height: `${h}%` }} 
              />
            ))}
          </div>
        </section>

        {/* Task Management Overview */}
        <section className="col-span-1 md:col-span-8 bento-card">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              Workflow Analysis
            </h2>
            <div className="flex gap-2">
              <span className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold uppercase rounded-lg">Status Map</span>
            </div>
          </div>
          
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 600 }}
                />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={40}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Distribution Pie */}
        <section className="col-span-1 md:col-span-6 bento-card">
          <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-6">Task Distribution</h2>
          <div className="h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  innerRadius={70}
                  outerRadius={90}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-6 mt-2">
              {chartData.map((item, i) => (
                <div key={item.name} className="flex items-center gap-2 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  {item.name}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Quick Actions / Info */}
        <section className="col-span-1 md:col-span-6 bg-slate-900 text-white rounded-3xl p-8 shadow-xl flex flex-col justify-between">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-6">System Management</h2>
            <div className="flex items-center gap-4 mb-8">
              <div className="h-12 w-12 rounded-2xl bg-blue-500 flex items-center justify-center text-white">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg leading-none">Global Performance</h3>
                <p className="text-slate-400 text-sm mt-1">Status: Operational</p>
              </div>
            </div>
            <p className="text-slate-400 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              Database connected successfully
            </p>
          </div>
          <div className="mt-8 flex gap-3">
             <button className="flex-1 bg-white text-slate-900 py-3 rounded-2xl text-sm font-bold shadow-lg hover:bg-slate-50 transition-all">
               Team Settings
             </button>
             <button className="flex-1 bg-slate-800 text-white py-3 rounded-2xl text-sm font-bold border border-slate-700 hover:bg-slate-700 transition-all">
               System Logs
             </button>
          </div>
        </section>
      </main>
    </div>
  );
}

function StatCard({ title, value, icon, color }: { title: string, value: number, icon: React.ReactNode, color: string }) {
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-200"
    >
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-neutral-500 uppercase tracking-wider">{title}</p>
          <h4 className="text-3xl font-bold mt-2 text-neutral-900">{value}</h4>
        </div>
        <div className={`p-3 rounded-xl ${color}`}>
          {icon}
        </div>
      </div>
    </motion.div>
  );
}
