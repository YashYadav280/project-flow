import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { 
  Plus, 
  Search, 
  Briefcase, 
  Users, 
  Calendar,
  ChevronRight,
  MoreVertical,
  Loader2
} from 'lucide-react';
import { motion } from 'motion/react';
import ProjectModal from '../components/ProjectModal';

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { user } = useAuth();

  const fetchProjects = async () => {
    try {
      const { data } = await api.get('/projects');
      setProjects(data);
    } catch (err) {
      console.error('Failed to fetch projects', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const filteredProjects = projects.filter((p: any) => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Projects</h1>
          <p className="text-neutral-500 mt-1">Manage and track all project workspace</p>
        </div>
        {user?.role === 'Admin' && (
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-indigo-200"
          >
            <Plus className="w-5 h-5" />
            New Project
          </button>
        )}
      </div>

      <div className="mb-8 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 w-5 h-5" />
        <input 
          type="text"
          placeholder="Search projects..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all shadow-sm"
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-10 h-10 animate-spin text-indigo-500" /></div>
      ) : filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project: any) => (
            <ProjectCard key={project._id} project={project} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-neutral-200 p-20 text-center">
          <Briefcase className="w-16 h-16 text-neutral-200 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-neutral-900">No projects found</h3>
          <p className="text-neutral-500 mt-2">Get started by creating your first project.</p>
        </div>
      )}

      {isModalOpen && (
        <ProjectModal 
          onClose={() => setIsModalOpen(false)} 
          onSuccess={() => {
            fetchProjects();
            setIsModalOpen(false);
          }}
        />
      )}
    </div>
  );
}

function ProjectCard({ project }: { project: any }) {
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className="bg-white border border-slate-200 rounded-3xl shadow-sm hover:shadow-md transition-all overflow-hidden group flex flex-col"
    >
      <div className="p-6 flex-1">
        <div className="flex justify-between items-start mb-6">
          <div className="p-3 bg-blue-50 rounded-2xl border border-blue-100">
            <Briefcase className="w-6 h-6 text-blue-600" />
          </div>
          <button className="text-slate-300 hover:text-slate-500 transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
        
        <h3 className="text-xl font-bold text-slate-800 group-hover:text-blue-600 transition-colors mb-3">
          {project.name}
        </h3>
        <p className="text-slate-400 text-sm line-clamp-2 mb-6 font-medium">
          {project.description}
        </p>

        <div className="flex items-center gap-4 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-t border-slate-50 pt-6">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-50 rounded-lg">
            <Users className="w-3.5 h-3.5" />
            <span>{project.members.length} members</span>
          </div>
          <div className="flex items-center gap-1.5 ml-auto">
            <Calendar className="w-3.5 h-3.5" />
            <span>{new Date(project.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
      
      <Link 
        to={`/projects/${project._id}`}
        className="block bg-slate-50 py-4 px-6 text-center text-xs font-bold uppercase tracking-widest text-blue-600 hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-2 border-t border-slate-100"
      >
        Open Workspace
        <ChevronRight className="w-4 h-4" />
      </Link>
    </motion.div>
  );
}
