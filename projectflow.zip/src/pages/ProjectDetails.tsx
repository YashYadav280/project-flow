import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { 
  Plus, 
  ArrowLeft, 
  Settings, 
  MoreVertical, 
  Search,
  CheckCircle2,
  Clock,
  Timer,
  Loader2,
  ListTodo
} from 'lucide-react';
import { motion } from 'motion/react';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function ProjectDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [project, setProject] = useState<any>(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [search, setSearch] = useState('');

  const fetchData = async () => {
    try {
      const [projRes, tasksRes] = await Promise.all([
        api.get(`/projects/${id}`),
        api.get(`/tasks?projectId=${id}`)
      ]);
      setProject(projRes.data);
      setTasks(tasksRes.data);
    } catch (err) {
      console.error('Failed to fetch project details', err);
      navigate('/projects');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const filteredTasks = tasks.filter((t: any) => 
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    t.assignedTo?.name.toLowerCase().includes(search.toLowerCase())
  );

  const stats = {
    total: tasks.length,
    completed: tasks.filter((t: any) => t.status === 'Completed').length,
    inProgress: tasks.filter((t: any) => t.status === 'In Progress').length,
    todo: tasks.filter((t: any) => t.status === 'To Do').length,
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="w-10 h-10 animate-spin text-indigo-500" /></div>;

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <button 
          onClick={() => navigate('/projects')}
          className="flex items-center gap-2 text-neutral-500 hover:text-indigo-600 transition-colors mb-4 group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Back to Projects
        </button>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">{project.name}</h1>
            <p className="text-neutral-500 mt-1">{project.description}</p>
          </div>
          <div className="flex items-center gap-3">
            {user?.role === 'Admin' && (
              <button 
                onClick={() => setIsTaskModalOpen(true)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-indigo-200"
              >
                <Plus className="w-5 h-5" />
                Add Task
              </button>
            )}
            <button className="p-2.5 rounded-xl border border-neutral-200 bg-white text-neutral-500 hover:bg-neutral-50 transition-all">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10">
        <MiniStat label="Total Tasks" value={stats.total} color="bg-blue-50 text-blue-600" />
        <MiniStat label="To Do" value={stats.todo} color="bg-slate-50 text-slate-500" />
        <MiniStat label="In Progress" value={stats.inProgress} color="bg-blue-50 text-blue-700" />
        <MiniStat label="Completed" value={stats.completed} color="bg-emerald-50 text-emerald-700" />
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
        <h2 className="text-xl font-bold text-neutral-900">Project Tasks</h2>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 w-4 h-4" />
          <input 
            type="text"
            placeholder="Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
          />
        </div>
      </div>

      {filteredTasks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTasks.map((task: any) => (
            <TaskCard 
              key={task._id} 
              task={task} 
              onUpdate={() => fetchData()} 
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-neutral-200 p-20 text-center">
          <Clock className="w-12 h-12 text-neutral-200 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No tasks found</h3>
          <p className="text-neutral-500">There are no tasks matching your current search.</p>
        </div>
      )}

      {isTaskModalOpen && (
        <TaskModal 
          projectId={id!} 
          onClose={() => setIsTaskModalOpen(false)} 
          onSuccess={() => {
            fetchData();
            setIsTaskModalOpen(false);
          }}
        />
      )}
    </div>
  );
}

function MiniStat({ label, value, color = "bg-blue-50 text-blue-600" }: { label: string, value: number, color?: string }) {
  return (
    <div className={cn("p-6 rounded-3xl border border-slate-100 shadow-sm", color)}>
      <p className="text-[10px] font-black uppercase tracking-widest opacity-70 mb-2">{label}</p>
      <p className="text-3xl font-black">{value}</p>
    </div>
  );
}
