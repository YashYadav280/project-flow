import { Request, Response, NextFunction } from 'express';
import { IUser, UserRole } from '../models/User.js';

interface AuthRequest extends Request {
  user?: IUser;
}

export const roleMiddleware = (roles: UserRole[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Forbidden: Insufficient permissions' });
    }

    next();
  };
};
