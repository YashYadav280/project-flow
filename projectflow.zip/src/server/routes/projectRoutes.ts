import { Router } from 'express';
import { createProject, getProjects, getProjectById, updateProject, deleteProject } from '../controllers/projectController.js';
import { authMiddleware } from '../middleware/authMiddleware.js';
import { roleMiddleware } from '../middleware/roleMiddleware.js';
import { UserRole } from '../models/User.js';

const router = Router();

router.use(authMiddleware);

router.get('/', getProjects);
router.get('/:id', getProjectById);

// Admin only routes
router.post('/', roleMiddleware([UserRole.ADMIN]), createProject);
router.put('/:id', roleMiddleware([UserRole.ADMIN]), updateProject);
router.delete('/:id', roleMiddleware([UserRole.ADMIN]), deleteProject);

export default router;
