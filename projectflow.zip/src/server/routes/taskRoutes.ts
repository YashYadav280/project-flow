import { Router } from 'express';
import { createTask, getTasks, updateTask, deleteTask } from '../controllers/taskController.js';
import { authMiddleware } from '../middleware/authMiddleware.js';
import { roleMiddleware } from '../middleware/roleMiddleware.js';
import { UserRole } from '../models/User.js';

const router = Router();

router.use(authMiddleware);

router.post('/', roleMiddleware([UserRole.ADMIN]), createTask);
router.get('/', getTasks);
router.put('/:id', updateTask); // Members can update their own tasks (logic in controller)
router.delete('/:id', roleMiddleware([UserRole.ADMIN]), deleteTask);

export default router;
