import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { User, UserRole } from '../models/User.js';
import { z } from 'zod';

const signupSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.nativeEnum(UserRole).optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const generateTokens = (id: string) => {
  const accessToken = jwt.sign({ id }, process.env.JWT_ACCESS_SECRET || 'secret', { expiresIn: '1h' });
  const refreshToken = jwt.sign({ id }, process.env.JWT_REFRESH_SECRET || 'refresh_secret', { expiresIn: '7d' });
  return { accessToken, refreshToken };
};

export const signup = async (req: Request, res: Response) => {
  try {
    const validated = signupSchema.parse(req.body);
    const existingUser = await User.findOne({ email: validated.email });

    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(validated.password, 10);
    const user = await User.create({
      ...validated,
      password: hashedPassword,
    });

    const tokens = generateTokens(user._id as string);
    res.status(201).json({ user: { id: user._id, name: user.name, email: user.email, role: user.role }, ...tokens });
  } catch (error) {
    res.status(400).json({ message: error instanceof Error ? error.message : 'Signup failed' });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    const validated = loginSchema.parse(req.body);
    const user = await User.findOne({ email: validated.email });

    if (!user || !(await bcrypt.compare(validated.password, user.password || ''))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const tokens = generateTokens(user._id as string);
    res.json({ user: { id: user._id, name: user.name, email: user.email, role: user.role }, ...tokens });
  } catch (error) {
    res.status(400).json({ message: error instanceof Error ? error.message : 'Login failed' });
  }
};

export const getMe = async (req: any, res: Response) => {
  res.json({ user: { id: req.user._id, name: req.user.name, email: req.user.email, role: req.user.role } });
};
