import { Request, Response } from 'express';
import { Task, TaskStatus } from '../models/Task.js';
import { UserRole } from '../models/User.js';
import { z } from 'zod';

const taskSchema = z.object({
  title: z.string().min(2),
  description: z.string(),
  dueDate: z.string().transform(str => new Date(str)),
  assignedTo: z.string(),
  project: z.string(),
  status: z.nativeEnum(TaskStatus).optional(),
});

export const createTask = async (req: any, res: Response) => {
  try {
    const validated = taskSchema.parse(req.body);
    const task = await Task.create(validated);
    res.status(201).json(task);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

export const getTasks = async (req: any, res: Response) => {
  try {
    const { projectId } = req.query;
    const query: any = {};
    if (projectId) query.project = projectId;
    
    // Members can only see their own tasks if not filtered by project
    if (req.user.role !== UserRole.ADMIN && !projectId) {
      query.assignedTo = req.user._id;
    }

    const tasks = await Task.find(query).populate('assignedTo', 'name email').populate('project', 'name');
    res.json(tasks);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

export const updateTask = async (req: any, res: Response) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    // Members can ONLY update status of their assigned tasks
    if (req.user.role !== UserRole.ADMIN) {
      if (task.assignedTo.toString() !== req.user._id.toString()) {
        return res.status(403).json({ message: 'Cannot update tasks not assigned to you' });
      }
      // Restrict update to status only
      task.status = req.body.status || task.status;
    } else {
      // Admin can update anything
      Object.assign(task, req.body);
    }

    await task.save();
    res.json(task);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

export const deleteTask = async (req: any, res: Response) => {
  try {
    if (req.user.role !== UserRole.ADMIN) {
      return res.status(403).json({ message: 'Only admins can delete tasks' });
    }
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};
