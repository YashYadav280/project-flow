import { Request, Response } from 'express';
import { Project } from '../models/Project.js';
import { UserRole } from '../models/User.js';
import { z } from 'zod';

const projectSchema = z.object({
  name: z.string().min(2),
  description: z.string().min(5),
  members: z.array(z.string()).optional(),
});

export const createProject = async (req: any, res: Response) => {
  try {
    const validated = projectSchema.parse(req.body);
    const project = await Project.create({
      ...validated,
      createdBy: req.user._id,
      members: validated.members || [req.user._id],
    });
    res.status(201).json(project);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

export const getProjects = async (req: any, res: Response) => {
  try {
    // Admins see everything, Members see projects they are in
    const query = req.user.role === UserRole.ADMIN ? {} : { members: req.user._id };
    const projects = await Project.find(query).populate('createdBy', 'name email').populate('members', 'name email');
    res.json(projects);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

export const getProjectById = async (req: any, res: Response) => {
  try {
    const project = await Project.findById(req.params.id)
      .populate('createdBy', 'name email')
      .populate('members', 'name email');
    
    if (!project) return res.status(404).json({ message: 'Project not found' });
    
    // Authorization check for non-admins
    if (req.user.role !== UserRole.ADMIN && !project.members.some(m => m._id.toString() === req.user._id.toString())) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    res.json(project);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

export const updateProject = async (req: any, res: Response) => {
  try {
    const project = await Project.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

export const deleteProject = async (req: any, res: Response) => {
  try {
    const project = await Project.findByIdAndDelete(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json({ message: 'Project deleted' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};
