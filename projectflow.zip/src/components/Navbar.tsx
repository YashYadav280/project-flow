import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, Briefcase, LogOut, User, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white border border-slate-200 rounded-3xl p-4 shadow-sm mb-6 sticky top-0 z-50 mt-4 mx-4 md:mx-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="bg-blue-600 h-10 w-10 rounded-xl flex items-center justify-center text-white transition-transform group-hover:scale-105">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-800">ProjectFlow</h1>
          </Link>
          
          <div className="hidden md:flex items-center gap-2">
            <Link
              to="/"
              className="px-4 py-2 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-50 hover:text-blue-600 transition-all"
            >
              Dashboard
            </Link>
            <Link
              to="/projects"
              className="px-4 py-2 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-50 hover:text-blue-600 transition-all"
            >
              Projects
            </Link>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex flex-col items-end border-r border-slate-100 pr-4">
            <span className="text-sm font-bold text-slate-800 leading-none">{user?.name}</span>
            <span className="text-[10px] uppercase tracking-wider text-blue-600 font-bold bg-blue-50 px-2 rounded-full mt-1">
              {user?.role}
            </span>
          </div>
          
          <div className="relative group">
            <div className="h-10 w-10 rounded-full border-2 border-white shadow-sm font-display overflow-hidden bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white font-bold cursor-pointer">
              {user?.name.charAt(0)}
            </div>
            
            <div className="absolute right-0 top-full pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              <div className="bg-white border border-slate-200 rounded-xl shadow-xl p-2 w-48">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
