import api from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { 
  Clock, 
  User, 
  Trash2, 
  CheckCircle2, 
  AlertCircle,
  MoreHorizontal
} from 'lucide-react';
import { motion } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function TaskCard({ task, onUpdate }: { task: any, onUpdate: () => void }) {
  const { user } = useAuth();

  const handleStatusChange = async (newStatus: string) => {
    try {
      await api.put(`/tasks/${task._id}`, { status: newStatus });
      onUpdate();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        await api.delete(`/tasks/${task._id}`);
        onUpdate();
      } catch (err) {
        console.error(err);
      }
    }
  };

  const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'Completed';

  const statusIcons = {
    'To Do': <ListTodo className="w-5 h-5 text-slate-400" />,
    'In Progress': <Timer className="w-5 h-5 text-blue-600" />,
    'Completed': <CheckCircle2 className="w-5 h-5 text-emerald-600" />,
  };

  const statusStyles = {
    'To Do': 'bg-slate-100 text-slate-500',
    'In Progress': 'bg-blue-100 text-blue-700',
    'Completed': 'bg-emerald-100 text-emerald-700',
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      className={cn(
        "bg-white border rounded-3xl p-5 shadow-sm transition-all flex items-center gap-5 hover:border-blue-200",
        isOverdue ? "border-red-100 bg-red-50/20" : "border-slate-100"
      )}
    >
      <div className={cn(
        "h-12 w-12 rounded-full flex items-center justify-center shrink-0 shadow-inner",
        task.status === 'Completed' ? 'bg-emerald-50' : 
        task.status === 'In Progress' ? 'bg-blue-50' : 'bg-slate-50'
      )}>
        {isOverdue ? <AlertCircle className="w-6 h-6 text-red-500" /> : statusIcons[task.status as keyof typeof statusIcons]}
      </div>

      <div className="flex-1 min-w-0">
        <h4 className="text-base font-bold text-slate-800 leading-tight truncate">{task.title}</h4>
        <div className="flex items-center gap-3 mt-1.5">
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
             <User className="w-3 h-3" />
             {task.assignedTo?.name}
          </p>
          <p className={cn(
            "text-[11px] font-bold flex items-center gap-1",
            isOverdue ? "text-red-500" : "text-slate-400"
          )}>
             <Clock className="w-3 h-3" />
             {new Date(task.dueDate).toLocaleDateString()}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <span className={cn(
          "px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg border border-transparent",
          statusStyles[task.status as keyof typeof statusStyles],
          isOverdue && task.status !== 'Completed' && "bg-red-500 text-white border-red-400"
        )}>
          {isOverdue && task.status !== 'Completed' ? 'Overdue' : task.status}
        </span>

        <div className="flex gap-1">
          {(task.status === 'To Do' || task.status === 'In Progress') && (
            <button
               onClick={() => handleStatusChange(task.status === 'To Do' ? 'In Progress' : 'Completed')}
               className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"
               title={task.status === 'To Do' ? 'Start Task' : 'Complete Task'}
            >
               <CheckCircle2 className="w-5 h-5" />
            </button>
          )}
          {user?.role === 'Admin' && (
            <button 
              onClick={handleDelete}
              className="p-1.5 hover:bg-red-50 text-red-400 rounded-lg transition-colors"
              title="Delete Task"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}
